#include <iostream>
using namespace std;
int main(){ float P,R,T; cin>>P>>R>>T; cout<<"SI = "<<(P*R*T)/100; return 0; }