#include <iostream>
using namespace std;
int main(){ float l,w; cin>>l>>w; cout<<"Area = "<<l*w; return 0; }